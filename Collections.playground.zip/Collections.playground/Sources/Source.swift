import Foundation

public class CuddlyCreature {
    public var softFur = true
}